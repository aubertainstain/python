def soma(num1, num2, num3):

    return num1 + num2 + num3

numero1 = float(input("Digite o primeiro número: "))
numero2 = float(input("Digite o segundo número: "))
numero3 = float(input("Digite o terceiro número: "))



print("A soma dos três números é:", soma(numero1,numero2,numero3))
