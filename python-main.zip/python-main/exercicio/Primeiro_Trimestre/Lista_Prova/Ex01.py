x = 5
y = 5


soma = x + y
